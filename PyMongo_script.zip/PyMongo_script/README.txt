
Create a local virtual env:
===========================


python3 -m venv menv

. ./menv/bin/activate

Install modules:
================

pip3 install flask pymongo python-json-logger


NOTE:
=====

Update the all scripts to use the IP address of the mongoDB server instead of 'localhost'.
Using 'localhost' will not allow accessing the flask server from a different system.


# Load Student records [port: 30001]
mongoimport --uri "mongodb://localhost:30001/school" --collection grade9 --type json --jsonArray < student.json 


# Connect to mongodb:
mongosh --host localhost  --port 30001

# check data:

test> show dbs
admin       40.00 KiB
config      72.00 KiB
local       72.00 KiB
school      40.00 KiB  <== DB to use =====
venky        1.73 MiB
test>

test> use school
switched to db school
school> show collections
grade9
school>

# Read data from grade9 collections. Show 10 records
# shows 10 random records

school> db.grade9.find().limit(10).pretty()
[
  {
    _id: ObjectId('67116400d3baed93979dde64'),
    id: 32,
    name: 'Freddy Mercury',
    marks: { maths: 90, physics: 88, english: 92, history: 86, spanish: 79 }
  },
  {
    _id: ObjectId('67116400d3baed93979dde65'),
    id: 1,
    name: 'Alice Smith',
    marks: { maths: 85, physics: 78, english: 92, history: 88, spanish: 74 }
  },
  {
    _id: ObjectId('67116400d3baed93979dde66'),
    id: 3,
    name: 'Charlie Brown',
    marks: { maths: 92, physics: 89, english: 95, history: 84, spanish: 77 }
  },
<SNIP>


To get all records where maths >= 65:
====================================

school> db.grade9.find( {"marks.maths": { $gte: 65 } } ).pretty()
[
  {
    _id: ObjectId('67116400d3baed93979dde64'),
    id: 32,
    name: 'Freddy Mercury',
    marks: { maths: 90, physics: 88, english: 92, history: 86, spanish: 79 }
  },
  {
    _id: ObjectId('67116400d3baed93979dde65'),
    id: 1,
    name: 'Alice Smith',
    marks: { maths: 85, physics: 78, english: 92, history: 88, spanish: 74 }
  },
  {
    _id: ObjectId('67116400d3baed93979dde66'),
    id: 3,
    name: 'Charlie Brown',
    marks: { maths: 92, physics: 89, english: 95, history: 84, spanish: 77 }
  },
<SNIP>

Students scored more than 75 in both maths and english:
========================================================

Using $and for and query:

school> db.grade9.find({ $and: [{ "marks.maths": { $gt: 75 } }, { "marks.english": { $gt: 75 } }] });
[
  {
    _id: ObjectId('67116400d3baed93979dde64'),
    id: 32,
    name: 'Freddy Mercury',
    marks: { maths: 90, physics: 88, english: 92, history: 86, spanish: 79 }
  },
  {
    _id: ObjectId('67116400d3baed93979dde65'),
    id: 1,
    name: 'Alice Smith',
    marks: { maths: 85, physics: 78, english: 92, history: 88, spanish: 74 }
  },
<SNIP>



Using $or for OR query:

school> db.grade9.find({ $or: [{ "marks.maths": { $gt: 90 } }, { "marks.english": { $lt: 80 } }] });





Get sample data:
================

wget https://github.com/mongodb-developer/datasets/raw/refs/heads/master/one_big_list.json
mv one_big_list.json sample.json


Load data from sample.json:
============================

hostip=localhost
port=30001
dbname=mytest
mongoimport --uri "mongodb://$hostip:$port/$dbname" --collection customer --type json --jsonArray < sample.json 


Check data:
===========

mongosh --host localhost  --port 3000

test> show dbs
admin    40.00 KiB
config  108.00 KiB
local    72.00 KiB
test     72.00 KiB
mytest     1.73 MiB
test>

test> use mytest
switched to db mytest
mytest>

mytest> show collections
customer
mytest>



Start flask app:
===============

1. Update IP and port number as needed in the myapp.py

2. python3 ./myapp


Goto the browser:
=================

http://<hostip>:5000


