import base64
import logging
from pythonjsonlogger import jsonlogger

def logmsg(text_message):
  log_format = "%(asctime)s - %(module)s#%(lineno)d - %(levelname)s - %(message)s"
  file_formatter = formatter = jsonlogger.JsonFormatter(fmt=log_format, rename_fields={"levelname": "level", "asctime": "date"})
  logger = logging.getLogger()
  file_handler = logging.FileHandler('mylog.json', mode="a")
  file_handler.setFormatter(file_formatter)
  logger.addHandler(file_handler)
  logger.setLevel(logging.INFO)
  logger.info(text_message)


logmsg("Hello")
