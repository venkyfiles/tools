
from pymongo import MongoClient
import gridfs

uri=f'mongodb://10.216.177.108:30001/'
dbname = 'mytest'
audio_filename = 'sample4.mp3'
#audio_filename = 'sample.js' #WORKED

def retrieve_audio_from_mongodb(audio_filename, db_name=dbname):
    client = MongoClient(uri)  # Adjust the URI if needed
    db = client[db_name]
    fs = gridfs.GridFS(db)
    
    # Find the file by filename
    audio_data = fs.find_one({'filename': audio_filename})
    if audio_data:
        # Save the audio to a file
        with open(audio_filename, 'wb') as output_file:
            output_file.write(audio_data.read())
        print(f"Audio file '{audio_filename}' retrieved from MongoDB.")
    else:
        print("Audio file not found.")

if __name__ == "__main__":
    retrieve_audio_from_mongodb(audio_filename)

