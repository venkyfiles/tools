from pymongo import MongoClient
import gridfs

uri=f'mongodb://10.216.177.108:30001/'
dbname = 'mytest'
audio_path = '/root/PyMongo/audio/sample4.mp3'
#audio_path = '/root/PyMongo/audio/sample.js' # WORKED

def store_audio_in_mongodb(audio_file_path, db_name=dbname):
    # Connect to MongoDB
    client = MongoClient(uri)  # Adjust the URI if needed
    db = client[db_name]
    
    # Create a GridFS object
    fs = gridfs.GridFS(db)

    # Open the audio file and store it in GridFS
    with open(audio_file_path, 'rb') as audio_file:
        fs.put(audio_file, filename=audio_file_path.split('/')[-1])
    
    print(f"Audio file '{audio_file_path}' stored in MongoDB.")

if __name__ == "__main__":

    store_audio_in_mongodb(audio_path)

