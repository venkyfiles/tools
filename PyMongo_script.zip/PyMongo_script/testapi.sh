
curl -X PUT http://localhost:5000/update/<item_id> \
     -H "Content-Type: application/json" \
     -d '{"field1": "new_value1", "field2": "new_value2"}'

