#!/bin/bash

# Define the directory containing the text files
DIRECTORY="./"

# Define the string to find and the string to replace it with
FIND_STRING="localhost"
REPLACE_STRING="localhost"

# Loop through all text files in the directory
for FILE in "$DIRECTORY"/*; do
    # Check if the file exists
    if [[ -f "$FILE" ]]; then
        # Use sed to perform the replacement
        sed -i "s/$FIND_STRING/$REPLACE_STRING/g" "$FILE"
        echo "Updated $FILE"
    fi
done

