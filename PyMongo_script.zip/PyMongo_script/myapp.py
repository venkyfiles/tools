from flask import Flask, render_template
from pymongo import MongoClient

# folder for index.html
app = Flask(__name__, template_folder='html')

# Userdata
mongo_server_ip = "localhost"
mongodb_port = 30001
uri=f'mongodb://{mongo_server_ip}:{mongodb_port}/'
db_name = "mytest"
collection_name = "customer"

print('mongo_server_ip: {}'.format(mongo_server_ip))
print('port: {}'.format(mongodb_port))
print('db_name: {}'.format(db_name))

#### MAIN #######

# Connect to MongoDB
client = MongoClient(uri)

# DB
db = client[db_name]
collection = db[collection_name]

@app.route('/')
def index():
    # Retrieve data from MongoDB
    data = list(collection.find())
    return render_template('index.html', data=data)

if __name__ == '__main__':  # Corrected typo here
    app.run(host=mongo_server_ip, debug=True)

