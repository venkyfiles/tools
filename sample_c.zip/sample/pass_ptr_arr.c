/*
 * Author:
 * Last Updated:
 */

#include<stdio.h>
#include<stdlib.h>

#define ARRAY_SIZE 20




/*
 * Display data
 */

void
print_data(int *arr, int sz)
{
  for (int i=0; i< sz; i++) {
       printf("%d.  %d\n",i, arr[i]);
      }
}


// MAIN Program

int
main(int argc, char**argv)
{
  int *ptr;
  
  ptr = (int*) malloc(ARRAY_SIZE * sizeof(int));

  for (int i=0; i<ARRAY_SIZE; i++) {
    ptr[i] = i * (i+1);
   }

  print_data(ptr, ARRAY_SIZE);
}


