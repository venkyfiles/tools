#include<stdio.h>


int
main(int argc, char** argv)
{
  printf("program name: "); printf("%s\n", argv[0]);

  if (argv[1] != NULL) {
    printf("arg1 name: "); printf("%s\n", argv[1]);
    }
  if (argv[2] != NULL) {
    printf("arg2 name: "); printf("%s\n", argv[2]);
    }
}
