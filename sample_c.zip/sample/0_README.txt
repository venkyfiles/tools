C programming topics:
=====================

File operations using open and fopen calls
Network programs using socket
IPC programs (Inter Process Communication)
 - signals
 - memory mapping
 - shared memory
 - semaphore
Multi threading - Threads 
 - POSIX Threads

