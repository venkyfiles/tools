#include<stdio.h>
#include<string.h>

int
main(int argc, char** argv) 
{

 char x[10] = "abcdefghij";

 if (strcmp(x, "abcdefghij")) {
     printf("not same");
    }
}
