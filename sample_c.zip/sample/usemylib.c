#include "mylib.h"



int
main(int argc, char** argv)
{
  show_sizeof_ptr();
  return 0;
}


