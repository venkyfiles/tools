#include <stdio.h>

int
main(int argc, char** argv)
{

  int data1;
  float  data2;

  printf("enter data1: ");
  scanf("%d", &data1);

  printf("enter data2: ");
  scanf("%2f", &data2);


  printf("data1 = %d  data2 = %f\n", data1, data2);

}




