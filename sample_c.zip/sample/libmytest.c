#include<stdio.h>
#include<stdlib.h>

void
show_sizeof_ptr(void)
{
  int *ptr;
  float *pp;
  char *cha;

  printf("Size of ptr = %d\n", (int)sizeof(ptr));
  printf("Size of pp = %d\n", (int)sizeof(pp));
  printf("Size of cha = %d\n", (int)sizeof(cha));
}


void
msg(char* m)
{
  printf("INFO: %s\n", m);
}
