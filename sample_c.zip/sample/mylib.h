
void show_sizeof_ptr(void);
void msg(char*);
