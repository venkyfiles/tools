#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <wait.h>

int main() {
    pid_t pid = fork(); // Create a child process

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }

    if (pid == 0) {
        // Child process
        printf("Child process PID: %d\n",  getpid());
        while (1) {
            // Infinite loop to keep the child process alive
            printf("Child waiting...\n");
            sleep(1);
        }
    } else {
        // Parent process
        sleep(2); // Wait before sending the signal
        printf("Parent process (PID: %d) sending SIGUSR1 signal to child (PID: %d)\n", getpid(), pid);
        kill(pid, SIGUSR1); // Send SIGUSR1 signal to child
        wait(NULL); // Wait for the child to finish
    }

    return 0;
}

