/*
 * Author:
 * Last Updated:
 */

#include<stdio.h>
#include<stdlib.h>

#define ROW 5
#define COL 5


/*
 * Display data
 */

void
show_data(int **arr)
{
  for (int j=0; j<COL; j++) {
    for (int i=0; i<ROW; i++) {
       printf("[%d]    ", arr[j][i]);
      }
    printf("\n");
   }
}


// MAIN Program

int
main(int argc, char**argv)
{
  int **ptr = NULL;
  int i=0, j=0;

  /* Init ptrs */
  ptr = (int**) malloc (ROW * sizeof(int*));
  for (i=0; i<ROW; i++) {
    ptr[i] = (int*) malloc(COL * sizeof(int));
   }

  /* Load data */
  for (j=0; j < ROW; j++) {
    for (i=0; i < COL; i++) {
      ptr[j][i] = i+j ;
     }
  }
  show_data(ptr);
}


